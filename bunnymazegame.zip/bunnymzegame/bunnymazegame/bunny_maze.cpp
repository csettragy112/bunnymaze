//Program name: bunny_maze.cpp
//Author: Cesar Samson
//Date last updated: 5/7/2018
//Purpose: Maze game where after every move, you need to answer a question and you get the number of bunnies stored in the maze cell.


#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include <vector>
#include <map>
#include <ctime>

using namespace std;

#define SIZE 5

int maze[10][10];
vector<string> questions[10];
vector<string> options[10];
vector<int> correct_ans[10];

int x, y;

map<string, string> password;
map<string, vector<int> > previous_scores;

void initMaze()
{
	for (int i = 0; i<SIZE; i++)
		for (int j = 0; j<SIZE; j++)
		{
			maze[i][j] = 1 + rand() % 9;
		}
}
void printMaze()
{
	for (int i = 0; i<SIZE; i++)
	{
		cout << "|";
		for (int j = 0; j<SIZE; j++)
			cout << "----";
		cout << endl;
		cout << "|";
		for (int j = 0; j<SIZE; j++)
		{
			cout << " ";
			if (i == x && j == y)
				cout << "*";
			else
				cout << maze[i][j];
			cout << " |";
		}
		cout << endl;
	}
	for (int j = 0; j<SIZE; j++)
		cout << "----";
	cout << endl;

}




void loadQuestions()
{
	ifstream fp("Questions.txt");
	while (!fp.eof())
	{
		string s;
		int diff;
		getline(fp, s);
		diff = s[0] - '0';
		getline(fp, s);
		questions[diff].push_back(s);
		string temp = "";
		for (int i = 0; i<3; i++)
		{
			temp += to_string(i + 1) + ") ";
			getline(fp, s);
			temp += s;
			temp += "\n";
		}
		options[diff].push_back(temp);
		getline(fp, s);
		correct_ans[diff].push_back(s[0] - '0');
	}
	fp.close();
}

void printQuestion(int diff, int num)
{
	cout << questions[diff][num] << "?" << endl;
	cout << options[diff][num];
}

int validInteger(string ch, int limit)
{
	char temp = '0' + limit;
	if (ch.size() != 1)
		return false;
	if (ch[0] < '1' || ch[0] > temp)
		return false;
	return true;
}

int rightPossible(int x)
{
	if (x < (SIZE - 1))
		return true;
	return false;
}

int downPossible(int y)
{
	if (y < (SIZE - 1))
		return true;
	return false;
}


void displayStats(string username)
{
	if (previous_scores.find(username) == previous_scores.end())
	{
		cout << "You've never played this game before." << endl;
		return;
	}

	cout << "You have played this game " << previous_scores[username].size() << " times." << endl;

	cout << "Your previous scores are(latest first): \n";

	vector<int> last_scores = previous_scores[username];
	for (int i = last_scores.size() - 1; i >= 0; i--)
		cout << last_scores[i] << endl;

	cout << endl;
}

int main(int argc, char const *argv[])
{
	srand(time(NULL));
	loadQuestions();

	cout << "Welcome to the system!" << endl;
	string current_username = "";

	while (true)
	{
		cout << "1) Signup\n2) Login\n3) Play game\n4) Logout\n5) Display my stats\n6) Exit the program\n";
		cout << "Enter choice: ";
		string ch;
		cin >> ch;

		while (!validInteger(ch, 6))
		{
			cout << "Invalid input. Enter again: ";
			cin >> ch;
		}

		string username, pass;
		if (ch == "6")
			break;
		if (ch == "1")
		{
			if (current_username != "")
			{
				cout << "Logout first and then signup for a new user." << endl;
				continue;
			}
			cout << "Enter a username: ";
			cin >> username;

			while (password.find(username) != password.end())
			{
				cout << "Username already exists. Choose another name: ";
				cin >> username;
			}

			cout << "Choose a password: ";
			cin >> pass;
			password[username] = pass;
			cout << "Congratulations! Account created!" << endl;
		}
		else if (ch == "2")
		{
			if (current_username != "")
			{
				cout << "Please logout to login again." << endl;
				continue;
			}
			cout << "Enter username: ";
			cin >> username;

			if (password.find(username) == password.end())
				cout << "Username does not exist. Signup first and then try to login." << endl;
			else
			{
				cout << "Enter password: ";
				cin >> pass;

				if (password[username] != pass)
				{
					int tries_left = 3;
					while (password[username] != pass && tries_left > 0)
					{
						cout << "Incorrect password. You have " << tries_left << " tries left. Enter password: ";
						cin >> pass;
						tries_left--;
					}
				}
				if (password[username] != pass)
					continue;

				current_username = username;
				cout << "Login successful!" << endl;

			}
		}
		else if (ch == "3")
		{
			if (current_username == "")
			{
				cout << "Please login to play the game." << endl;
				continue;
			}

			if (previous_scores.find(current_username) != previous_scores.end())
			{
				cout << "Your previous scores are: \n";
				vector<int> last_scores = previous_scores[current_username];
				for (int i = last_scores.size() - 1; i >= 0; i--)
					cout << last_scores[i] << endl;

				cout << endl;
			}

			else
			{
				cout << "Looks like you are playing the game for the first time, here are the rules:\n" << endl;
				cout << "In this game, starting at the top left corner, you need to traverse the maze, collect few bunnies(points) and reach the bottom corner with atleast 30 points." << endl;
				cout << "You can only move down and right. When you move to a cell, you will get a question that you need to answer correctly to get the bunnies in the cell" << endl;
				cout << "More the points, more difficult the question will be. So, choose carefully.Best of luck!" << endl;
			}

			while (true)
			{
				initMaze();

				int curScore = 0;
				x = 0, y = 0;

				while (true)
				{
					printMaze();
					cout << "You are at (" << x + 1 << ", " << y + 1 << ")" << endl;
					int diff = maze[x][y];
					cout << "Time for a question! You can get " << diff << " points if you answer the following question correctly!" << endl;

					int num = questions[diff].size();
					int r = rand() % num;
					printQuestion(diff, r);
					cout << "Choose option 1,2 or 3: ";
					string ch;
					cin >> ch;

					while (!validInteger(ch, 3))
					{
						cout << "Invalid input. Enter again: ";
						cin >> ch;
					}
					int choice = ch[0] - '0';

					if (choice != correct_ans[diff][r])
						cout << "Incorrect answer. You do not get the bunnies for this cell" << endl;
					else
					{
						curScore += diff;
						cout << "Correct answer! You gained " << diff << " bunnies!" << endl;
					}

					if (x == (SIZE - 1) && y == (SIZE - 1))
						break;

					cout << "Your current score is: " << curScore << endl;

					if (rightPossible(x) && downPossible(y))
					{
						cout << "Do you want to go down or right? Enter 1 for down and 2 for right: ";
						cin >> ch;
						while (!validInteger(ch, 2))
						{
							cout << "Invalid input. Enter again: ";
							cin >> ch;
						}
						if (ch == "1")
							x += 1;
						else
							y += 1;
					}

					else if (downPossible(y))
					{
						cout << "You can only go down." << endl;
						y += 1;
					}

					else
					{
						cout << "You can only go right." << endl;
						x += 1;
					}


				}

				cout << "You have reached the bottom corner with " << curScore << " points." << endl;

				if (curScore >= 30)
					cout << "You win!";
				else
					cout << "You lose.";
				previous_scores[current_username].push_back(curScore);
				cout << "\nDo you want to play again? Enter 1 to play again, 2 to exit: ";
				string ch;
				cin >> ch;

				while (!validInteger(ch, 2))
				{
					cout << "Invalid input. Enter again: ";
					cin >> ch;
				}

				if (ch == "2")
					break;
			}


		}
		else if (ch == "4")
		{
			if (current_username == "")
			{
				cout << "No login found." << endl;
			}
			else
			{
				current_username = "";
				cout << "Logout successful." << endl;
			}
		}
		else
		{
			if (current_username == "")
			{
				cout << "No login found." << endl;
			}
			else
			{
				displayStats(current_username);
			}

		}
	}

	cout << "Thank you for using the program! Good Bye..." << endl;

	return 0;
}